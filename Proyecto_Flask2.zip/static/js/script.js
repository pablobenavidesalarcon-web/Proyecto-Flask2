
let contador = 0;

const contadorCarrito = document.getElementById("contadorCarrito");


const botonesAgregar = document.querySelectorAll(".boton-agregar");

for (let i = 0; i < botonesAgregar.length; i++) {
    botonesAgregar[i].addEventListener("click", function () {
        contador = contador + 1;
        contadorCarrito.textContent = contador;

        
        botonesAgregar[i].textContent = "agregado";
        setTimeout(function () {
            botonesAgregar[i].textContent = "Agregar al carrito";
        }, 1000);
    });
}


const botonMenu = document.getElementById("botonMenu");
const menu = document.getElementById("menu");

botonMenu.addEventListener("click", function () {
    menu.classList.toggle("mostrar");
});


const formulario = document.getElementById("formularioContacto");
const mensajeEnviado = document.getElementById("mensajeEnviado");

formulario.addEventListener("submit", function (evento) {
    evento.preventDefault();

    mensajeEnviado.style.display = "block";
    formulario.reset();
});
