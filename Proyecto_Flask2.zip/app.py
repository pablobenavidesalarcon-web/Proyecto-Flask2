from flask import Flask, render_template

app = Flask(__name__)


productos = [
    {
        "nombre": "Pastillas de freno",
        "descripcion": "Sirven para autos como Chevrolet Sail y Aveo.",
        "precio": "CLP:$24.990"
    },
    {
        "nombre": "Bateria 12V",
        "descripcion": "Bateria para autos y camionetas medianas.",
        "precio": "CLP:$69.990"
    },
    {
        "nombre": "Amortiguadores",
        "descripcion": "Par de amortiguadores traseros, con garantia.",
        "precio": "CLP:$54.990"
    },
    {
        "nombre": "Filtro de aceite",
        "descripcion": "Filtro mas aceite 5W-30 de 4 litros.",
        "precio": "CLP:$32.990"
    },
    {
        "nombre": "Neumatico 185/65 R15",
        "descripcion": "Neumatico para uso urbano y de carretera.",
        "precio": "CLP:$59.990"
    },
    {
        "nombre": "Faros LED",
        "descripcion": "Par de faros LED, mas luz y menos consumo.",
        "precio": "CLP:$38.990"
    },
]


equipo = ["Pablo Benavides", "Tomas Lupallante", "Raul Burgos"]


@app.route("/")
def inicio():
   
    return render_template("index.html", productos=productos, equipo=equipo)

if __name__ == "__main__":
    app.run(debug=True)
