# AutoPartes Linares

Pagina hecha con Flask para una tienda de repuestos de autos en Linares, Chile.

Equipo: Pablo Benavides, Tomas Lupallante, Raul Burgos

## Que hace

- Muestra una lista de productos (usando una lista de Python en app.py)
- Cada producto tiene un boton "Agregar al carrito" que suma un contador arriba
- Tiene un formulario de contacto que muestra un mensaje al enviarlo
- El menu se puede abrir y cerrar en el celular

## Como correrlo

1. Entrar a la carpeta:
```
cd Proyecto_Flask
```

2. Crear el entorno virtual:
```
python -m venv venv
```

3. Activarlo:

Windows:
```
venv\Scripts\activate
```

Mac/Linux:
```
source venv/bin/activate
```

4. Instalar flask:
```
pip install -r requirements.txt
```

5. Correr la app:
```
python app.py
```

6. Abrir en el navegador:
```
http://127.0.0.1:5000/
```
